package br.com.bratatouille.management.production.service;

import br.com.bratatouille.management.production.entity.Production;
import br.com.bratatouille.management.production.repository.ProductionRepository;
import br.com.bratatouille.management.purchase.repository.PurchaseItemRepository;
import br.com.bratatouille.management.recipe.entity.Recipe;
import br.com.bratatouille.management.recipe.entity.RecipeItem;
import br.com.bratatouille.management.recipe.repository.RecipeRepository;
import br.com.bratatouille.management.stock.service.StockService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class ProductionService {

    private final ProductionRepository productionRepository;
    private final RecipeRepository recipeRepository;
    private final PurchaseItemRepository purchaseItemRepository;
    private final StockService stockService;

    public ProductionService(
            ProductionRepository productionRepository,
            RecipeRepository recipeRepository,
            PurchaseItemRepository purchaseItemRepository,
            StockService stockService
    ) {
        this.productionRepository = productionRepository;
        this.recipeRepository = recipeRepository;
        this.purchaseItemRepository = purchaseItemRepository;
        this.stockService = stockService;
    }

    @Transactional
    public Production create(Long recipeId, BigDecimal producedQuantity) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RuntimeException("Recipe not found"));

        BigDecimal totalCost = calculateTotalCost(recipe, producedQuantity);

        consumeRecipeItems(recipe, producedQuantity);

        stockService.addFromProduction(recipe.getOutputItem(), producedQuantity);

        Production production = Production.create(
                recipe,
                producedQuantity,
                totalCost
        );

        return productionRepository.save(production);
    }

    private BigDecimal calculateTotalCost(Recipe recipe, BigDecimal producedQuantity) {
        BigDecimal totalCost = BigDecimal.ZERO;

        for (RecipeItem recipeItem : recipe.getItems()) {
            BigDecimal consumedQuantity = recipeItem.getQuantity()
                    .multiply(producedQuantity);

            BigDecimal averageUnitCost = purchaseItemRepository
                    .findAverageUnitCostByItemId(recipeItem.getItem().getId());

            if (averageUnitCost == null || averageUnitCost.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException(
                        "Item has no cost history: " + recipeItem.getItem().getId()
                );
            }

            BigDecimal itemCost = averageUnitCost.multiply(consumedQuantity);

            totalCost = totalCost.add(itemCost);
        }

        return totalCost;
    }

    private void consumeRecipeItems(Recipe recipe, BigDecimal producedQuantity) {
        for (RecipeItem recipeItem : recipe.getItems()) {
            BigDecimal consumedQuantity = recipeItem.getQuantity()
                    .multiply(producedQuantity);

            stockService.removeForProduction(
                    recipeItem.getItem(),
                    consumedQuantity
            );
        }
    }
}